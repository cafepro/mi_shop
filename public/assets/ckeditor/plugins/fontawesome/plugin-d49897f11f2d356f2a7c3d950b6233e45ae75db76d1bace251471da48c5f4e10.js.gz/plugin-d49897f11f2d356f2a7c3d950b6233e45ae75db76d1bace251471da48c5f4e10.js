/*
	Author	: Michael Janea (https://facebook.com/mbjanea)
	Version	: 1.1
*/


eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('e.y.b(\'c\',{D:\'C\',A:\'c\',j:8(f){f.z.b(\'m\',{x:\'w u t\',p:\'<7 5="" 9=""></7>\',k:\'l\',n:\'7(!d){9}\',o:8(1){q 1.r==\'7\'&&1.s(\'d\')},j:8(){0.a(\'5\',0.1.v(\'5\'));0.a(\'4\',0.1.i(\'4\'));0.a(\'6\',0.1.i(\'g-6\'))},3:8(){B 2=\'\';0.1.h(\'5\',0.3.5);2+=0.3.4!=\'\'?\'4:\'+0.3.4+\';\':\'\';2+=0.3.6!=\'\'?\'g-6:\'+E(0.3.6)+\'F;\':\'\';2!=\'\'?0.1.h(\'9\',2):\'\';2==\'\'?0.1.G(\'9\'):\'\'}});e.k.b(\'l\',0.H+\'I/c.J\')}});',46,46,'this|element|istayl|data|color|class|size|span|function|style|setData|add|fontawesome|fa|CKEDITOR|editor|font|setAttribute|getStyle|init|dialog|fontawesomeDialog|FontAwesome|allowedContent|upcast|template|return|name|hasClass|Awesome|Font|getAttribute|Insert|button|plugins|widgets|icons|var|widget|requires|parseInt|px|removeAttribute|path|dialogs|js'.split('|'),0,{}))
;
